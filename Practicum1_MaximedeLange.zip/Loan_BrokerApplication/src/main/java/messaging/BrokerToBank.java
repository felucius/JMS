package messaging;

import com.google.gson.Gson;
import loanbroker.LoanBrokerFrame;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

import javax.naming.NamingException;
import model.bank.BankInterestRequest;
import model.loan.LoanRequest;

/*
This class send the messages from the Broker application to the Bank application
*/
public class BrokerToBank {

    Connection connection = null;
    Session session = null;
    Destination destination = null;
    MessageProducer producer = null;
    LoanBrokerFrame frame = null;

    public BrokerToBank(LoanBrokerFrame frame) {
        this.frame = frame;
        try {
            /*
            Creating properties to connect with ActiveMQ. Setting up the library
            and the url to connect with.
            */
            Properties properties = new Properties();
            properties.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.activemq.jndi.ActiveMQInitialContextFactory");
            properties.setProperty(Context.PROVIDER_URL, "tcp://localhost:61616");

            /*
            Sending the messages to the queue BrokerToBank
            */
            properties.put(("queue.FromBrokerToBank"), "FromBrokerToBank");

            /*
            Craeting a connection factory in the JNDI context.
            */
            Context jndiContext = new InitialContext(properties);
            ConnectionFactory connectionFactory = (ConnectionFactory) jndiContext.lookup("ConnectionFactory");;

            /*
            Connect to the created JNDI connection factory.
            */
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            /*
            Setting up the destination to send the message to. In our case the Bank
            or FromBrokerToBank.
            */
            destination = (Destination) jndiContext.lookup("FromBrokerToBank");
            producer = session.createProducer(destination);

        } catch (NamingException | JMSException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * This method send the loanrequest from the bank with the bankinterest request
     * and the correlation to the client.
     * @param loanRequest is the request from the client application.
     * @param request is the request from the bank on the loanrequest.
     * @param correlation is the matching JMS ID on the loanrequest and bankinterst
     * request.
     */
    public void send(LoanRequest loanRequest, BankInterestRequest request, String correlation) {
        try {
            /*
            Creating a Json message from the given request from the bank and set
            the JMS correlation ID to that certain request so it matches the 
            loanrequest from the Client application.
            */
            Message message = session.createTextMessage(new Gson().toJson(request));
            message.setJMSCorrelationID(correlation);
            producer.send(message);

            /*
            Adding the JMS correlation ID to the given loanrequest from the Client.
            */
            frame.correlations.put(correlation, loanRequest);
            session.close();
            connection.close();
        } catch (JMSException ex) {
            ex.printStackTrace();
        }
    }
}

package messaging;

import com.google.gson.Gson;
import loanbroker.LoanBrokerFrame;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;

import javax.naming.NamingException;
import model.loan.LoanReply;

/*
This class sends the information from to Broker application to the Client application
by sending the Google version of Json format to ActiveMQ.
*/
public class BrokerToClient {

    Connection connection = null;
    Session session = null;
    Destination destination = null;
    MessageProducer producer = null;
    LoanBrokerFrame frame = null;

    public BrokerToClient(LoanBrokerFrame frame) {
        this.frame = frame;
        try {
            /*
            Creating properties with the activeMQ library and URL to connect with
            ActiveMQ
            */
            Properties properties = new Properties();
            properties.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.activemq.jndi.ActiveMQInitialContextFactory");
            properties.setProperty(Context.PROVIDER_URL, "tcp://localhost:61616");

            /*
            The queue to retrieve information from.
            */
            properties.put(("queue.FromBrokerToClient"), "FromBrokerToClient");

            /*
            Creating JNDI connection factory.
            */
            Context jndiContext = new InitialContext(properties);
            ConnectionFactory connectionFactory = (ConnectionFactory) jndiContext.lookup("ConnectionFactory");;

            /*
            Create a connection from the lookup in the JDNI context.
            */
            connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);

            /*
            Setting the destination to look from in ActiveMQ. In our case the
            Broker.
            */
            destination = (Destination) jndiContext.lookup("FromBrokerToClient");
            producer = session.createProducer(destination);

        } catch (NamingException | JMSException ex) {
            ex.printStackTrace();
        }
    }

    /**
     * This method sends the reply and and correlation to the client application.
     * @param reply is the reply from the Bank application.
     * @param correlation is the JMS correlation ID, so that the request matches
     * the reply ID message ID.
     */
    public void send(LoanReply reply, String correlation) {
        try {
            /*
            Creating a Json message from the given reply from the bank.
            */
            Message message = session.createTextMessage(new Gson().toJson(reply));
            message.setJMSCorrelationID(correlation);
            producer.send(message);
            
            session.close();
            connection.close();
        } catch (JMSException ex) {
            ex.printStackTrace();
        }
    }
}

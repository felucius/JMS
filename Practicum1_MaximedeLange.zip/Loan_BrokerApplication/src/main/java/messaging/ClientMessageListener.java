package messaging;

import com.google.gson.Gson;
import loanbroker.LoanBrokerFrame;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;
import model.bank.BankInterestRequest;
import model.loan.LoanRequest;

/*
This class listens to the messages received from the client application.
*/
public class ClientMessageListener implements MessageListener {    
    private final LoanBrokerFrame frame;
    
    public ClientMessageListener(LoanBrokerFrame frame) {
        this.frame = frame;
    }
    
    @Override
    public void onMessage(Message msg) {
        try {
            /*
            Creating a message from the retrieved Google Json format of LoanRequest
            object. The GUI frame adds the loanrequest to the Broker GUI frame.
            After that the Broker sends the request to the bank.
            */
            TextMessage message = (TextMessage) msg;
            LoanRequest loanRequest = new Gson().fromJson(message.getText(), LoanRequest.class);
            frame.add(loanRequest);
            
            /*
            Sending the messages, given from the Client application
            to the Bank application.
            */
            BrokerToBank sender = new BrokerToBank(frame);
            BankInterestRequest interestRequest = new BankInterestRequest(loanRequest.getAmount(), loanRequest.getTime());
            sender.send(loanRequest, interestRequest, message.getJMSMessageID());
            frame.add(loanRequest, interestRequest);
        } catch (JMSException ex) {
            ex.printStackTrace();
        }
    }
}
